clc
clear
clear functions
%
% -----------------------------------------------------------
% 	Introducao ao Calculo Numerico usando o Octave/Matlab		              
%             Prof. Andrea Valli
%------------------------------------------------------------
% Descricao do Trabalho 
% -----------------------------------------------------------
introd
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
%
% -----------------------------------------------------------
% Parte I - Resolucao de Sistemas Lineares
% -----------------------------------------------------------
ex1
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
%
% -----------------------------------------------------------
% Parte 2 - Ajuste de Curvas
% -----------------------------------------------------------
ex2
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
%
% -----------------------------------------------------------
% Parte 3 - Solucao de Equacoes Diferenciais Ordinarias
% -----------------------------------------------------------
ex3
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
% -----------------------------------------------------------
% Parte 4 - Raizes de Equacoes
% -----------------------------------------------------------
ex4
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
% -----------------------------------------------------------
% Parte 5 - Interpolacao
% -----------------------------------------------------------
ex5
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
% -----------------------------------------------------------
% Parte 6 - Integracao
% -----------------------------------------------------------
ex6
disp(' ');
disp('Tecle alguma coisa para continuar...'); pause
%
% -----------------------------------------------------------
% Final da Apresentacao
% -----------------------------------------------------------
disp(' ');
disp('Tecle alguma coisa para terminar a apresentacao...'); pause
clc
