% Introducao
clc
clear
disp(' ');
disp('Introducao ao Calculo Numerico usando o Octave/Matlab'); 
disp('Prof. Andrea Valli');
disp(' ');
disp('Programa:');
disp('1. Resolucao de Sistemas Lineares');
disp('2. Ajuste de Curvas');
disp('3. Equacoes Diferenciais Ordinarias');
disp('4. Raizes de Equacoes');
disp('5. Interpolacao');
disp('6. Integracao');
disp('7. Introducao ao metodo das diferencas finitas');



